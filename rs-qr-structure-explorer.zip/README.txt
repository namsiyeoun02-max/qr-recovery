QR 구조 탐색 추가 버전

index.html을 열면 사이트를 볼 수 있습니다. 별도 설치가 필요 없습니다.

배포: GitHub에서 현재 Vercel Root Directory로 지정된 폴더(index.html이 있는 폴더)에 이 ZIP 안의 파일을 업로드하세요. 폴더 이름을 바꾸거나 새 폴더 안에 넣지 마세요.
기존 index.html, styles.css, app.js, site-qr.svg를 교체하고 qr-explorer.css, qr-explorer.js를 추가합니다. Commit changes 후 Vercel 배포가 Ready인지 확인하세요.

변경: 표지 다음 QR 구조 탐색 추가, 8개 구역 클릭 설명, 강조 해제, 모바일 세로 배치, 키보드 Enter/Space 선택. 기존 RS 계산 코드는 유지했습니다.
예시 QR: 버전 2 / M / 마스크 0 / https://rs-qr.vercel.app/
발표 자료의 QR 구성 요소를 바탕으로 설명을 구성했습니다. 다크 모듈은 고정 검은 모듈로 설명하고 BCH 포맷 보호와 RS 데이터 정정을 구분했습니다.

검증: 구역별 모듈 수, 8개 설명 선택, 강조 해제, 기존 RS 복원 검산을 확인했습니다.
